import fsp from 'fs/promises';

// BEGIN
async function getTypes(paths) {
  const getType = async (path) => {
    try {
      const stats = await fsp.stat(path);
      return stats.isDirectory() ? 'directory' : 'file';
    } catch (error) {
      return null;
    }
  };

  const typePromises = paths.map((path) => getType(path));
  return Promise.all(typePromises);
}
export { getTypes };
// END